package constants;

public class AppConstants {

	public static final String chromeDriverLocation = "/Users/rajorshi/Downloads/chromedriver";

	public static final String loginUrl = "https://phptravels.org/clientarea.php";
	public static final String email = "test_selenium@gmail.com";
	public static final String pwd = "abcd123";
	public static final String navigateUrl="https://phptravels.org/clientarea.php?action=invoices";

}
