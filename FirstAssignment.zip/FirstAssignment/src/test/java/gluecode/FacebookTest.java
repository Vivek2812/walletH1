package gluecode;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import constants.AppConstants;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FacebookTest {
	WebDriver driver = null;

	@Given("^I am on Facebook login page$")
	public void i_am_on_Facebook_login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", AppConstants.chromeDriverLocation);
		driver = new ChromeDriver();
		driver.navigate().to("https://www.facebook.com/");
	}

	@When("^I enter username as \"([^\"]*)\"$")
	public void i_enter_username_as(String arg1) throws Throwable {
		driver.findElement(By.id("email")).sendKeys(arg1);
	}

	@When("^I enter password as \"([^\"]*)\"$")
	public void i_enter_password_as(String arg1) throws Throwable {
		driver.findElement(By.id("pass")).sendKeys(arg1);
		driver.findElement(By.id("u_0_8")).click();
	


		driver.close();
		driver.quit();
	}

}
